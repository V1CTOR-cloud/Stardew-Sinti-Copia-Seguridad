let fondo = document.querySelector('.imagen');
let dia_noche = document.querySelector('.dia_noche');
let menu = document.querySelector('.menuToggle');
let body = document.querySelector('body');
let nav = document.querySelector('.nav');
let logotipo = document.querySelector('.logo_img');

dia_noche.onclick = function() {
    dia_noche.classList.toggle('active');
    body.classList.toggle('dark');
    logotipo.classList.toggle('dark');

    if (dia_noche.classList.contains('active')) {
        fondo.setAttribute("src", "../img/index_oscuro.png");
    } else {
        fondo.setAttribute("src", "../img/index_claro.png");
    }
}

menu.onclick = function() {
    menu.classList.toggle('active');
    nav.classList.toggle('active');
}

nav.onclick = function() {
    nav.classList.toggle
}