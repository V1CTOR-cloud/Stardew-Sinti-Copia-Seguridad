let fondo = document.querySelector('.imagen');
let dia_noche = document.querySelector('.dia_noche');
let menu = document.querySelector('.menuToggle');
let body = document.querySelector('body');
let cont2 = document.querySelector('cont2');
let nav = document.querySelector('.nav');

dia_noche.onclick = function() {
    dia_noche.classList.toggle('active');
    body.classList.toggle('dark');
    fondo.setAttribute("src", "../img/oscuro_novedades.png");
    if (dia_noche.classList.contains('active')) {} else {
        fondo.setAttribute("src", "../img/claro_novedades.png");
        cont2.classList.remove('dark');
    }
}

menu.onclick = function() {
    menu.classList.toggle('active');
    nav.classList.toggle('active');
}