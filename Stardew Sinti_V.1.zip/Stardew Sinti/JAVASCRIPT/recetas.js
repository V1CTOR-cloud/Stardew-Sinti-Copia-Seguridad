let fondo = document.querySelector('.imagen');
let dia_noche = document.querySelector('.dia_noche');
let menu = document.querySelector('.menuToggle');
let body = document.querySelector('body');
let cont2 = document.querySelector('cont2');
let nav = document.querySelector('.nav');
let tools = document.querySelector('.drop');
let content = document.querySelector('.content');

dia_noche.onclick = function() {
    dia_noche.classList.toggle('active');
    body.classList.toggle('dark');
    fondo.setAttribute("src", "../img/oscuro_recetas.png");
    if (dia_noche.classList.contains('active')) {} else {
        fondo.setAttribute("src", "../img/claro_recetas.png");
        cont2.classList.remove('dark');
    }
}

menu.onclick = function() {
    menu.classList.toggle('active');
    nav.classList.toggle('active');
}

tools.onclick = function() {
    tools.classList.toggle('active');
    if (tools.classList.contains('active')) {
        tools.setAttribute("name", "caret-up-outline");
        content.classList.toggle('active');
    } else {
        tools.setAttribute("name", "caret-down-outline");
        tools.classList.remove('active');
        content.classList.remove('active');
    }
}