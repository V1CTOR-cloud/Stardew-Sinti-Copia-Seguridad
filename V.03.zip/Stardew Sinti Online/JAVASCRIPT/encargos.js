let fondo = document.querySelector('.imagen');
let dia_noche = document.querySelector('.dia_noche');
let menu = document.querySelector('.menuToggle');
let body = document.querySelector('body');
let nav = document.querySelector('.nav');
let box = document.getElementById('box');

dia_noche.onclick = function() {
    dia_noche.classList.toggle('active');
    body.classList.toggle('dark');
    fondo.setAttribute("src", "../img/oscuro_recetas.png");
    if (dia_noche.classList.contains('active')) {} else {
        fondo.setAttribute("src", "../img/claro_recetas.png");
        cont2.classList.remove('dark');
    }
}

menu.onclick = function() {
    menu.classList.toggle('active');
    nav.classList.toggle('active');
}

window.onmousemove = function(e) {
    box.style.transform = "rotateX(-30deg) rotateY(" +
        +e.clientX + "deg)"

}