let fondo = document.querySelector('.imagen');
let dia_noche = document.querySelector('.dia_noche');
let menu = document.querySelector('.menuToggle');
let body = document.querySelector('body');
let nav = document.querySelector('.nav');
let japon = document.getElementById('japan');
let italia = document.getElementById('italia');
let usa = document.getElementById('usa');
let mexico = document.getElementById('mexico');



dia_noche.onclick = function() {
    dia_noche.classList.toggle('active');
    body.classList.toggle('dark');
    fondo.setAttribute("src", "../img/oscuro_recetas.png");
    if (dia_noche.classList.contains('active')) {} else {
        fondo.setAttribute("src", "../img/claro_recetas.png");
        cont2.classList.remove('dark');
    }
}

menu.onclick = function() {
    menu.classList.toggle('active');
    nav.classList.toggle('active');
}



japon.onclick = function() {
    japon.classList.toggle('active');

    if (japon.classList.contains('active')) {

    } else {

    }
}